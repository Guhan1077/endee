
import streamlit as st
import pickle

model = pickle.load(open('model.pkl', 'rb'))
vectorizer = pickle.load(open('vectorizer.pkl', 'rb'))

st.title("Spam Email Detector")

email_text = st.text_area("Enter Email Text")

if st.button("Predict"):
    data = vectorizer.transform([email_text])
    prediction = model.predict(data)[0]
    if prediction == 1:
        st.error("Spam Email")
    else:
        st.success("Not Spam")
