
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
import pickle

# Sample dataset
data = {
    'text': [
        'Win money now!!!',
        'Hello friend, how are you?',
        'Claim your free prize',
        'Meeting tomorrow at 10',
        'You won a lottery',
        'Let us discuss the project'
    ],
    'label': [1, 0, 1, 0, 1, 0]
}

df = pd.DataFrame(data)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['text'])
y = df['label']

model = MultinomialNB()
model.fit(X, y)

pickle.dump(model, open('model.pkl', 'wb'))
pickle.dump(vectorizer, open('vectorizer.pkl', 'wb'))

print("Model trained and saved!")
