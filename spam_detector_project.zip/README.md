
# Spam Email Detector

This is a simple AI project that detects whether an email is spam or not using Machine Learning.

## Features
- Uses TF-IDF vectorization
- Naive Bayes classifier
- Streamlit web app

## Installation
```bash
pip install -r requirements.txt
```

## Train Model
```bash
python train_model.py
```

## Run App
```bash
streamlit run app.py
```
